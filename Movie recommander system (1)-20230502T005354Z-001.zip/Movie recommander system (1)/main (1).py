from tkinter import *
from tkinter import messagebox
from pct import recommend
from pct import *
import requests

from PIL import ImageTk, Image
import os
from io import BytesIO

#background color
bc="#111119"
framebg="#EDEDED" #283055
framefg="#06283D"

global inc
inc=0
def fetch_poster(movie_id,movie_title):
    
    global inc
    inc=inc+1
    
    print("increse",inc)

    text[f'a{inc}'].config(text=movie_title)

    url = "https://api.themoviedb.org/3/movie/{}?api_key=8265bd1679663a7ea12ac168da84d2e8&language=en-US".format(movie_id)
    data = requests.get(url)
    data = data.json()
    poster_path = data['poster_path']
    img_url = "https://image.tmdb.org/t/p/w500/" + poster_path
    response = requests.get(img_url)
    img_data = response.content
    img=(Image.open(BytesIO(img_data)))
    resized_image=img.resize((140,200))
    photo2 = ImageTk.PhotoImage(resized_image)
    image[f'b{inc}'].config(image=photo2)
    image[f'b{inc}'].image=photo2


def search():
    
    global inc
    name=Search.get().title()
    print(name)

    try:

        text=recommend(name)
        for i in text[1:6]:

            ##it for movie name
            movie_title=new.iloc[i[0]].title
            print(movie_title)
            
            movie_id=new.iloc[i[0]].movie_id
            print(movie_id)
            fetch_poster(movie_id,movie_title)

        inc=0

    except:
        messagebox.showinfo("info","No recommandation regarding this movie!!")

        
##        print(new.iloc[i[0]].title)


     
    



root=Tk()
root.title("5D Cinema")
root.geometry("1250x700+210+90")
root.config(bg=bc)





#icon
icon_image=PhotoImage(file="Images/icon.png")
root.iconphoto(False,icon_image)

#logo
logo_image=PhotoImage(file="Images/logo.png")
Label(root,image=logo_image,bg=bc).place(x=20,y=20)

heading=Label(root,text="Movie Recommender System",font=("Lato",35,'bold'),fg="white",bg=bc).place(x=140,y=90)

#setting
setting_image=PhotoImage(file="Images/setting.png")
Label(root,image=setting_image,bg=bc).place(x=1100,y=30)

#signin
signin_image=PhotoImage(file="Images/login.png")
Label(root,image=signin_image,bg=bc).place(x=1150,y=20)



#search box
search_box=PhotoImage(file="Images/Rectangle 2.png")
Label(root,image=search_box,bg=bc).pack(pady=150)

search_icon=PhotoImage(file="Images/Layer 17.png")
Label(root,image=search_icon,bg="#333340").place(x=180,y=165)


Search=StringVar()
search_entry=Entry(root,textvariable=Search,width=30,font=("Lato",25),bg="#333340",fg="#7f7f7f",bd=0)
search_entry.place(x=235,y=168)


#button
recommand_button_image=PhotoImage(file="Images/Recommend.png")
recommand_button=Button(root,image=recommand_button_image,bg=bc,bd=0,activebackground="#252532",cursor="hand1",command=search)
recommand_button.place(x=150,y=250)

#first frame
frame1=Frame(root,width=150,height=240,bg="white")
frame1.place(x=160,y=400)

#second frame
frame2=Frame(root,width=150,height=240,bg="white")
frame2.place(x=360,y=400)

#third frame
frame3=Frame(root,width=150,height=240,bg="white")
frame3.place(x=560,y=400)

#fouth frame
frame4=Frame(root,width=150,height=240,bg="white")
frame4.place(x=760,y=400)

#fifth frame
frame5=Frame(root,width=150,height=240,bg="white")
frame5.place(x=960,y=400)


text={'a1': Label(frame1,text="Movie name",font=("arial",10),fg="green"),'a2': Label(frame2,text="Movie name",font=("arial",10),fg="green"),'a3': Label(frame3,text="Movie name",font=("arial",10),fg="green"),'a4': Label(frame4,text="Movie name",font=("arial",10),fg="green"),'a5': Label(frame5,text="Movie name",font=("arial",10),fg="green")}
text['a1'].place(x=10,y=4)
text['a2'].place(x=10,y=4)
text['a3'].place(x=10,y=4)
text['a4'].place(x=10,y=4)
text['a5'].place(x=10,y=4)

##image1 = Label(frame1)
##image1.place(x=0,y=20)


image = {'b1': Label(frame1),'b2': Label(frame2),'b3': Label(frame3),'b4': Label(frame4),'b5': Label(frame5)}
image['b1'] = Label(frame1)
image['b1'].place(x=5,y=20)


image['b2'] = Label(frame2)
image['b2'].place(x=5,y=20)

image['b3'] = Label(frame3)
image['b3'].place(x=5,y=20)

image['b4'] = Label(frame4)
image['b4'].place(x=5,y=20)

image['b5'] = Label(frame5)
image['b5'].place(x=5,y=20)


root.mainloop()
